import { GoogleGenAI, Type } from "@google/genai";
import { GeneratedScripts, UserInput } from "../types";

// Ensure API key is present
const apiKey = process.env.API_KEY || '';

const ai = new GoogleGenAI({ apiKey });

export const generateBotScripts = async (input: UserInput): Promise<GeneratedScripts> => {
  if (!apiKey) {
    throw new Error("API Key is missing.");
  }

  const model = "gemini-2.5-flash";
  
  const prompt = `
    You are an expert copywriter and chatbot conversation designer.
    Generate a comprehensive set of chatbot scripts for a business with the following details:
    
    Business Name: ${input.businessName}
    Industry/Niche: ${input.industry}
    Target Audience: ${input.targetAudience}
    Tone of Voice: ${input.tone}
    ${input.specialOffer ? `Special Offer/Lead Magnet: ${input.specialOffer}` : ''}

    Create scripts for the following categories:
    1. Welcome Message (Initial greeting options)
    2. Lead Qualification (Questions to filter potential customers)
    3. Sales Conversion (Persuasive messages to close the deal)
    4. FAQ Auto-responses (Common questions for this specific industry)
    5. Appointment Setting (Inviting users to book a call/demo)
    6. Upsell + Cross-sell (Suggesting add-ons or upgrades)
    7. Follow-up Sequences (Re-engaging users who dropped off)

    For each category, provide 2-3 distinct variations (e.g., Short & Punchy, Detailed & Empathic, or specific scenarios).
    The content MUST be ready-to-copy, using placeholders like [Customer Name] or [Link] where appropriate.
    Use emojis where they fit the tone.
  `;

  // Define the schema for structured output
  const responseSchema = {
    type: Type.OBJECT,
    properties: {
      welcome: {
        type: Type.OBJECT,
        properties: {
          title: { type: Type.STRING },
          description: { type: Type.STRING },
          scripts: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                variant: { type: Type.STRING, description: "e.g., 'Casual', 'Professional', 'Urgent'" },
                content: { type: Type.STRING }
              }
            }
          }
        }
      },
      leadQualification: {
        type: Type.OBJECT,
        properties: {
          title: { type: Type.STRING },
          description: { type: Type.STRING },
          scripts: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                variant: { type: Type.STRING },
                content: { type: Type.STRING }
              }
            }
          }
        }
      },
      salesConversion: {
        type: Type.OBJECT,
        properties: {
          title: { type: Type.STRING },
          description: { type: Type.STRING },
          scripts: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                variant: { type: Type.STRING },
                content: { type: Type.STRING }
              }
            }
          }
        }
      },
      faq: {
        type: Type.OBJECT,
        properties: {
          title: { type: Type.STRING },
          description: { type: Type.STRING },
          scripts: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                variant: { type: Type.STRING, description: "The specific question being answered" },
                content: { type: Type.STRING, description: "The answer script" }
              }
            }
          }
        }
      },
      appointment: {
        type: Type.OBJECT,
        properties: {
          title: { type: Type.STRING },
          description: { type: Type.STRING },
          scripts: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                variant: { type: Type.STRING },
                content: { type: Type.STRING }
              }
            }
          }
        }
      },
      upsell: {
        type: Type.OBJECT,
        properties: {
          title: { type: Type.STRING },
          description: { type: Type.STRING },
          scripts: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                variant: { type: Type.STRING },
                content: { type: Type.STRING }
              }
            }
          }
        }
      },
      followUp: {
        type: Type.OBJECT,
        properties: {
          title: { type: Type.STRING },
          description: { type: Type.STRING },
          scripts: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                variant: { type: Type.STRING },
                content: { type: Type.STRING }
              }
            }
          }
        }
      },
    },
    required: ["welcome", "leadQualification", "salesConversion", "faq", "appointment", "upsell", "followUp"]
  };

  try {
    const response = await ai.models.generateContent({
      model: model,
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: responseSchema,
        temperature: 0.7, 
      },
    });

    const text = response.text;
    if (!text) {
        throw new Error("Empty response from AI");
    }
    
    return JSON.parse(text) as GeneratedScripts;

  } catch (error) {
    console.error("Error generating scripts:", error);
    throw error;
  }
};