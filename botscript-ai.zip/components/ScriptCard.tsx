import React, { useState } from 'react';
import { Copy, Check, MessageSquare, ChevronDown, ChevronUp, Layers } from 'lucide-react';
import { ScriptCategory } from '../types';

interface ScriptCardProps {
  categoryKey: string;
  categoryData: ScriptCategory;
  icon?: React.ReactNode;
}

const ScriptCard: React.FC<ScriptCardProps> = ({ categoryData, icon }) => {
  const [copiedIndex, setCopiedIndex] = useState<number | null>(null);
  const [copiedAll, setCopiedAll] = useState(false);
  const [isExpanded, setIsExpanded] = useState(true);

  const handleCopy = async (text: string, index: number) => {
    try {
      await navigator.clipboard.writeText(text);
      setCopiedIndex(index);
      setTimeout(() => setCopiedIndex(null), 2000);
    } catch (err) {
      console.error('Failed to copy text: ', err);
    }
  };

  const handleCopyAll = async (e: React.MouseEvent) => {
    e.stopPropagation();
    const allText = categoryData.scripts
      .map(s => `[${s.variant}]\n${s.content}`)
      .join('\n\n---\n\n');
      
    try {
      await navigator.clipboard.writeText(allText);
      setCopiedAll(true);
      setTimeout(() => setCopiedAll(false), 2000);
    } catch (err) {
      console.error('Failed to copy all: ', err);
    }
  };

  return (
    <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden mb-6 transition-all duration-300 hover:shadow-md">
      <div 
        className="p-4 bg-slate-50 border-b border-slate-200 flex items-center justify-between cursor-pointer select-none group"
        onClick={() => setIsExpanded(!isExpanded)}
      >
        <div className="flex items-center gap-3">
          <div className="p-2 bg-indigo-100 text-indigo-600 rounded-lg">
            {icon || <MessageSquare size={20} />}
          </div>
          <div>
            <h3 className="font-semibold text-slate-800 text-lg group-hover:text-indigo-700 transition-colors">{categoryData.title}</h3>
            <p className="text-sm text-slate-500">{categoryData.description}</p>
          </div>
        </div>
        
        <div className="flex items-center gap-2">
          <button
            onClick={handleCopyAll}
            className={`p-2 rounded-md transition-all duration-200 flex items-center gap-1.5 text-xs font-medium border ${
              copiedAll
                ? 'bg-green-100 text-green-700 border-green-200'
                : 'bg-white text-slate-500 hover:text-indigo-600 hover:bg-indigo-50 border-slate-200'
            }`}
            title="Copy all variations"
          >
            {copiedAll ? <Check size={14} /> : <Layers size={14} />}
            <span className="hidden sm:inline">{copiedAll ? 'Copied All' : 'Copy All'}</span>
          </button>
          
          <button className="text-slate-400 hover:text-slate-600 p-1">
            {isExpanded ? <ChevronUp size={20} /> : <ChevronDown size={20} />}
          </button>
        </div>
      </div>

      {isExpanded && (
        <div className="p-4 space-y-4">
          {categoryData.scripts.map((script, idx) => (
            <div key={idx} className="group relative border border-slate-100 rounded-lg bg-slate-50/50 hover:bg-white hover:border-indigo-100 transition-colors">
              <div className="absolute top-0 left-0 bg-indigo-500 text-white text-xs font-bold px-2 py-1 rounded-br-lg rounded-tl-lg z-10 shadow-sm">
                {script.variant}
              </div>
              
              <div className="p-6 pt-8 pr-12">
                <p className="text-slate-700 whitespace-pre-wrap font-mono text-sm leading-relaxed">
                  {script.content}
                </p>
              </div>

              <div className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity">
                <button
                  onClick={() => handleCopy(script.content, idx)}
                  className={`p-2 rounded-md transition-all duration-200 flex items-center gap-1.5 text-xs font-medium ${
                    copiedIndex === idx
                      ? 'bg-green-100 text-green-700'
                      : 'bg-white text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 border border-slate-200 shadow-sm'
                  }`}
                  title="Copy to clipboard"
                >
                  {copiedIndex === idx ? (
                    <>
                      <Check size={14} />
                      <span>Copied</span>
                    </>
                  ) : (
                    <>
                      <Copy size={14} />
                      <span>Copy</span>
                    </>
                  )}
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default ScriptCard;