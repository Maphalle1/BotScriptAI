export interface UserInput {
  businessName: string;
  industry: string;
  targetAudience: string;
  tone: string;
  specialOffer?: string;
}

export interface ScriptItem {
  variant: string;
  content: string;
}

export interface ScriptCategory {
  title: string;
  description: string;
  scripts: ScriptItem[];
}

export interface GeneratedScripts {
  welcome: ScriptCategory;
  leadQualification: ScriptCategory;
  salesConversion: ScriptCategory;
  faq: ScriptCategory;
  appointment: ScriptCategory;
  upsell: ScriptCategory;
  followUp: ScriptCategory;
}

export enum GenerationState {
  IDLE = 'IDLE',
  LOADING = 'LOADING',
  SUCCESS = 'SUCCESS',
  ERROR = 'ERROR',
}