import React, { useState, useRef, useEffect } from 'react';
import { 
  Bot, 
  Sparkles, 
  Send, 
  Loader2, 
  MessageCircle, 
  Users, 
  DollarSign, 
  HelpCircle, 
  Calendar, 
  TrendingUp, 
  Repeat,
  LayoutGrid,
  Download,
  CheckCircle2
} from 'lucide-react';
import { UserInput, GeneratedScripts, GenerationState } from './types';
import { generateBotScripts } from './services/geminiService';
import ScriptCard from './components/ScriptCard';

const initialInput: UserInput = {
  businessName: '',
  industry: '',
  targetAudience: '',
  tone: 'Professional yet Friendly',
  specialOffer: '',
};

const App: React.FC = () => {
  const [input, setInput] = useState<UserInput>(initialInput);
  const [status, setStatus] = useState<GenerationState>(GenerationState.IDLE);
  const [results, setResults] = useState<GeneratedScripts | null>(null);
  const [error, setError] = useState<string | null>(null);
  
  const resultsRef = useRef<HTMLDivElement>(null);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setInput(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.businessName || !input.industry) return;

    setStatus(GenerationState.LOADING);
    setError(null);
    setResults(null);

    try {
      const data = await generateBotScripts(input);
      setResults(data);
      setStatus(GenerationState.SUCCESS);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An unexpected error occurred');
      setStatus(GenerationState.ERROR);
    }
  };
  
  // Auto-scroll to results on mobile when success
  useEffect(() => {
    if (status === GenerationState.SUCCESS && resultsRef.current) {
      if (window.innerWidth < 768) {
         setTimeout(() => {
            resultsRef.current?.scrollIntoView({ behavior: 'smooth' });
         }, 100);
      }
    }
  }, [status]);

  const handleReset = () => {
    setStatus(GenerationState.IDLE);
    setResults(null);
    setInput(initialInput);
  };

  const handleDownload = () => {
    if (!results) return;

    let text = `BOT SCRIPT GENERATION FOR: ${input.businessName.toUpperCase()}\n`;
    text += `INDUSTRY: ${input.industry}\n`;
    text += `GENERATED ON: ${new Date().toLocaleDateString()}\n\n` + "=".repeat(50) + "\n\n";

    const categories: (keyof GeneratedScripts)[] = [
      'welcome', 'leadQualification', 'salesConversion', 
      'faq', 'appointment', 'upsell', 'followUp'
    ];

    categories.forEach(key => {
      const category = results[key];
      text += `[ ${category.title.toUpperCase()} ]\n`;
      text += `${category.description}\n\n`;
      
      category.scripts.forEach((script, idx) => {
        text += `--- Option ${idx + 1}: ${script.variant} ---\n\n`;
        text += `${script.content}\n\n`;
      });
      text += "=".repeat(50) + "\n\n";
    });

    const blob = new Blob([text], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${input.businessName.replace(/\s+/g, '_')}_BotScripts.txt`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="min-h-screen flex flex-col md:flex-row">
      {/* Sidebar / Configuration Panel */}
      <div className="w-full md:w-[400px] bg-white border-r border-slate-200 flex flex-col h-auto md:h-screen sticky top-0 z-20 shadow-xl md:shadow-none">
        <div className="p-6 border-b border-slate-100 flex items-center gap-3 bg-white">
          <div className="bg-indigo-600 p-2 rounded-lg">
            <Bot className="text-white w-6 h-6" />
          </div>
          <div>
            <h1 className="font-bold text-xl text-slate-900 tracking-tight">BotScript AI</h1>
            <p className="text-xs text-slate-500 font-medium">Script Generator</p>
          </div>
        </div>

        <div className="flex-1 overflow-y-auto p-6 scrollbar-thin bg-white">
          <form onSubmit={handleSubmit} className="space-y-5">
            <div>
              <label htmlFor="businessName" className="block text-sm font-medium text-slate-700 mb-1">Business Name</label>
              <input
                type="text"
                id="businessName"
                name="businessName"
                required
                className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-none transition-all text-sm"
                placeholder="e.g. Apex Fitness"
                value={input.businessName}
                onChange={handleInputChange}
              />
            </div>

            <div>
              <label htmlFor="industry" className="block text-sm font-medium text-slate-700 mb-1">Industry / Niche</label>
              <input
                type="text"
                id="industry"
                name="industry"
                required
                className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-none transition-all text-sm"
                placeholder="e.g. Online Personal Training"
                value={input.industry}
                onChange={handleInputChange}
              />
            </div>

            <div>
              <label htmlFor="targetAudience" className="block text-sm font-medium text-slate-700 mb-1">Target Audience</label>
              <input
                type="text"
                id="targetAudience"
                name="targetAudience"
                className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-none transition-all text-sm"
                placeholder="e.g. Busy professionals aged 30-45"
                value={input.targetAudience}
                onChange={handleInputChange}
              />
            </div>

            <div>
              <label htmlFor="tone" className="block text-sm font-medium text-slate-700 mb-1">Tone of Voice</label>
              <select
                id="tone"
                name="tone"
                className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-none transition-all text-sm bg-white"
                value={input.tone}
                onChange={handleInputChange}
              >
                <option>Professional yet Friendly</option>
                <option>High Energy & Enthusiastic</option>
                <option>Luxury & Sophisticated</option>
                <option>Casual & Relatable</option>
                <option>Direct & Sales-Focused</option>
                <option>Empathetic & Supportive</option>
                <option>Witty & Humorous</option>
              </select>
            </div>

            <div>
              <label htmlFor="specialOffer" className="block text-sm font-medium text-slate-700 mb-1">
                Special Offer / Lead Magnet <span className="text-slate-400 font-normal">(Optional)</span>
              </label>
              <textarea
                id="specialOffer"
                name="specialOffer"
                rows={3}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-none transition-all text-sm resize-none"
                placeholder="e.g. Free 7-day trial, 20% off first month, Free Ebook"
                value={input.specialOffer}
                onChange={handleInputChange}
              />
            </div>

            <button
              type="submit"
              disabled={status === GenerationState.LOADING || !input.businessName || !input.industry}
              className={`w-full py-3 px-4 rounded-lg flex items-center justify-center gap-2 font-medium text-white transition-all shadow-md hover:shadow-lg ${
                status === GenerationState.LOADING
                  ? 'bg-indigo-400 cursor-not-allowed'
                  : 'bg-indigo-600 hover:bg-indigo-700 active:scale-[0.98]'
              }`}
            >
              {status === GenerationState.LOADING ? (
                <>
                  <Loader2 className="animate-spin w-5 h-5" />
                  <span>Generating Scripts...</span>
                </>
              ) : (
                <>
                  <Sparkles className="w-5 h-5" />
                  <span>Generate Scripts</span>
                </>
              )}
            </button>
            
            {status === GenerationState.SUCCESS && (
               <button
               type="button"
               onClick={handleReset}
               className="w-full py-2 px-4 rounded-lg flex items-center justify-center gap-2 font-medium text-slate-600 bg-slate-100 hover:bg-slate-200 transition-all text-sm border border-slate-200"
             >
               Start Over
             </button>
            )}
          </form>
          
          <div className="mt-8 pt-6 border-t border-slate-100">
             <div className="bg-blue-50 p-4 rounded-lg border border-blue-100">
                <h4 className="text-blue-800 font-semibold text-sm mb-2 flex items-center gap-2">
                   <LayoutGrid size={16}/> Pro Tip
                </h4>
                <p className="text-blue-700 text-xs leading-relaxed">
                   Be specific about your audience for better results. The more details you provide, the more tailored your scripts will be.
                </p>
             </div>
          </div>
        </div>
        
        <div className="p-4 border-t border-slate-200 bg-slate-50 text-center text-xs text-slate-400 hidden md:block">
           Powered by Gemini 2.5 Flash
        </div>
      </div>

      {/* Main Content Area */}
      <div className="flex-1 bg-slate-50/50 h-auto md:h-screen overflow-y-auto scrollbar-thin relative scroll-smooth" ref={resultsRef}>
        {status === GenerationState.IDLE && (
          <div className="min-h-[60vh] md:h-full flex flex-col items-center justify-center p-8 text-center opacity-60">
             <div className="w-24 h-24 bg-indigo-100 rounded-full flex items-center justify-center mb-6">
                <Bot className="w-12 h-12 text-indigo-400" />
             </div>
             <h2 className="text-2xl font-bold text-slate-800 mb-2">Ready to Build Your Bot?</h2>
             <p className="text-slate-500 max-w-md mx-auto">
               Fill out the business details on the left to generate a complete suite of high-conversion chatbot scripts tailored to your brand.
             </p>
          </div>
        )}

        {status === GenerationState.LOADING && (
          <div className="min-h-[60vh] md:h-full flex flex-col items-center justify-center p-8 text-center">
             <div className="relative mb-8">
                <div className="w-20 h-20 border-4 border-indigo-100 border-t-indigo-600 rounded-full animate-spin"></div>
                <div className="absolute inset-0 flex items-center justify-center">
                   <Sparkles className="w-8 h-8 text-indigo-600" />
                </div>
             </div>
             <h2 className="text-xl font-semibold text-slate-800 animate-pulse">Designing your conversation flow...</h2>
             <p className="text-slate-500 mt-2">Crafting perfect responses for {input.industry}...</p>
          </div>
        )}

        {status === GenerationState.ERROR && (
          <div className="min-h-[60vh] md:h-full flex flex-col items-center justify-center p-8 text-center">
             <div className="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mb-4">
                <Bot className="w-8 h-8 text-red-500" />
             </div>
             <h2 className="text-xl font-bold text-slate-800 mb-2">Oops! Something went wrong.</h2>
             <p className="text-red-500 max-w-md mx-auto mb-6">{error}</p>
             <button onClick={() => setStatus(GenerationState.IDLE)} className="text-indigo-600 font-medium hover:underline">Try again</button>
          </div>
        )}

        {status === GenerationState.SUCCESS && results && (
          <div className="p-6 md:p-10 max-w-5xl mx-auto pb-20 animate-in fade-in slide-in-from-bottom-4 duration-500">
             <div className="mb-8 flex flex-col md:flex-row md:items-end justify-between gap-4">
                <div>
                  <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-green-100 text-green-700 rounded-full text-xs font-bold tracking-wide uppercase mb-3">
                     <CheckCircle2 size={14} />
                     Generated Successfully
                  </div>
                  <h2 className="text-3xl font-bold text-slate-900">Your Chatbot Script Kit</h2>
                  <p className="text-slate-500 mt-1">
                     Tailored for <span className="font-semibold text-indigo-600">{input.businessName}</span> ({input.industry})
                  </p>
                </div>
                
                <button 
                  onClick={handleDownload}
                  className="inline-flex items-center justify-center gap-2 px-4 py-2 bg-white border border-slate-300 rounded-lg text-slate-700 font-medium hover:bg-slate-50 hover:text-indigo-600 hover:border-indigo-200 transition-all shadow-sm"
                >
                  <Download size={18} />
                  Download .txt
                </button>
             </div>

             <div className="space-y-2">
                <ScriptCard 
                  categoryKey="welcome" 
                  categoryData={results.welcome} 
                  icon={<MessageCircle size={20} />} 
                />
                <ScriptCard 
                  categoryKey="leadQualification" 
                  categoryData={results.leadQualification} 
                  icon={<Users size={20} />} 
                />
                <ScriptCard 
                  categoryKey="salesConversion" 
                  categoryData={results.salesConversion} 
                  icon={<DollarSign size={20} />} 
                />
                <ScriptCard 
                  categoryKey="faq" 
                  categoryData={results.faq} 
                  icon={<HelpCircle size={20} />} 
                />
                <ScriptCard 
                  categoryKey="appointment" 
                  categoryData={results.appointment} 
                  icon={<Calendar size={20} />} 
                />
                <ScriptCard 
                  categoryKey="upsell" 
                  categoryData={results.upsell} 
                  icon={<TrendingUp size={20} />} 
                />
                <ScriptCard 
                  categoryKey="followUp" 
                  categoryData={results.followUp} 
                  icon={<Repeat size={20} />} 
                />
             </div>
             
             <div className="mt-12 p-8 bg-indigo-50 rounded-xl border border-indigo-100 text-center">
                <h3 className="text-lg font-semibold text-indigo-900 mb-2">Need more scripts?</h3>
                <p className="text-indigo-700 mb-4 max-w-lg mx-auto">
                   You can adjust the tone or target audience in the sidebar and regenerate to get a fresh set of variations.
                </p>
                <button 
                   onClick={() => resultsRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' })}
                   className="text-indigo-600 font-medium hover:underline"
                >
                   Scroll to top
                </button>
             </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default App;